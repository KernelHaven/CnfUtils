package com.bpodgursky.jbool_expressions.eval;

public class EvalSet {
}
