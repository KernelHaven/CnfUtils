package com.bpodgursky.jbool_expressions;

public class Seeds {

  protected static final int AND_SEED = 1483;
  protected static final int OR_SEED = 1487;

}
